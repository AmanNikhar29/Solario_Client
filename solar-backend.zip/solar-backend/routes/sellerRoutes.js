const express = require("express");
const router = express.Router();
const { getSellers,deleteSeller,updateSeller,registerSeller } = require("../controllers/sellerController"); // Ensure this is correctly imported

router.get("/getseller", getSellers);
router.get("/deleteSeller", deleteSeller); // Ensure this function is defined in sellerController.js
router.get("/updateSeller", updateSeller);
router.get("/registerSeller", registerSeller);

module.exports = router; // Export the router
